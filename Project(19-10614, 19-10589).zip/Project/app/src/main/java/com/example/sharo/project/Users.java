package com.example.sharo.project;

import java.util.List;

public class Users {
    public List<Requests> Requests;
    public List<Donations> Donations;
}

package com.example.sharo.project;

 public interface Myinterface {
    void ButtonClicked(String text);


 }

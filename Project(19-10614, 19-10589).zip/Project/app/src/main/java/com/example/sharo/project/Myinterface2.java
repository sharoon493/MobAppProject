package com.example.sharo.project;

 public interface Myinterface2 {
    void ButtonClicked(String text);
    void Country(String text);
    void data(String key,String data);



 }
